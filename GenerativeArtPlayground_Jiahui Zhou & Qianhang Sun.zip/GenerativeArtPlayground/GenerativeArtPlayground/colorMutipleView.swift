//
//  colorMutipleView.swift
//  GenerativeArtPlayground
//
//  Created by Jiahui Zhou on 11/26/17.
//  Copyright © 2017 IOS_programming. All rights reserved.
//

import UIKit

class colorMutipleView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
