//
//  ViewController.swift
//  DrawingApp
//
//  Created by Malek T. on 6/15/15.
//  Copyright (c) 2015 Medigarage Studios LTD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var imageView: UIImageView!
    @IBAction func saveImage(sender: AnyObject) {
        
    }
    @IBAction func undoDrawing(sender: AnyObject) {

    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

